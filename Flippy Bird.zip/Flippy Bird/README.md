This project belongs to Yahya Karabal. © CATERPILLAR ALL RIGHTS RESERVED.


Hello there. Yahya Karabal is me. First of all, I know Spanish, Arabic, French, Russian and English. My main field in java script and html software. I am studying at Khan Acedmy as a university. I have data management skills in software like Excel. There is a social structure that can be integrated into the agenda very quickly. In this way, I discover new technologies and plan my interests according to these issues.


For more: Mail adress: professionalsonlydonotdisturb@gmail.com


Этот проект принадлежит Яхье Карабалу. © CATERPILLAR ВСЕ ПРАВА ЗАЩИЩЕНЫ.


Привет. Яхья Карабал - это я. Прежде всего, я знаю испанский, арабский, французский, русский и английский языки. Мое основное поле в java-скриптах и html-программах. Я учусь в университете Хан Аседми. У меня есть навыки управления данными в программном обеспечении, таком как Excel. Есть социальная структура, которую можно очень быстро включить в повестку дня. Таким образом, я открываю для себя новые технологии и планирую свои интересы в соответствии с этими проблемами.


Для получения дополнительной информации: Почтовый адрес: professionalonlydonotdisturb@gmail.com 

Dieses Projekt gehört Yahya Karabal. © CATERPILLAR ALLE RECHTE VORBEHALTEN.


Hallo. Yahya Karabal bin ich. Zunächst einmal kann ich Spanisch, Arabisch, Französisch, Russisch und Englisch. Mein Hauptfeld in Java-Skript und HTML-Software. Ich studiere bei Khan Acedmy als Universität. Ich habe Datenmanagementfähigkeiten in Software wie Excel. Es gibt eine soziale Struktur, die sehr schnell in die Agenda integriert werden kann. Auf diese Weise entdecke ich neue Technologien und plane meine Interessen anhand dieser Themen.

Este proyecto pertenece a Yahya Karabal. © CATERPILLAR TODOS LOS DERECHOS RESERVADOS.


Hola. Yahya Karabal soy yo. En primer lugar, sé español, árabe, francés, ruso e inglés. Mi campo principal en scripts java y software html. Estoy estudiando en Khan Acedmy como universidad. Tengo habilidades de gestión de datos en software como Excel. Existe una estructura social que se puede integrar en la agenda muy rápidamente. De esta manera, descubro nuevas tecnologías y planifico mis intereses de acuerdo con estos temas.


Para más información: Dirección de correo: professionalsonlydonotdisturb@gmail.com

Bu proje Yahya Karabal'a aittir. © CATERPILLAR TÜM HAKLARI SAKLIDIR.


Merhaba. Yahya Karabal benim. Öncelikle İspanyolca, Arapça, Fransızca, Rusça ve İngilizce biliyorum. Java script ve html yazılımlarındaki ana alanım. Khan Acedmy'de üniversite olarak okuyorum. Excel gibi yazılımlarda veri yönetimi becerilerim var. Çok hızlı bir şekilde gündeme entegre edilebilecek bir sosyal yapı var. Bu sayede yeni teknolojiler keşfediyor ve ilgi alanlarımı bu konulara göre planlıyorum.


Daha fazlası için: Mail adresi: professionalsonlydonotdisturb@gmail.com
